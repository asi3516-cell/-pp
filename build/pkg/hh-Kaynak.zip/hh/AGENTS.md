# AGENTS.md

Portable Turkish-only IPTV/radio app ("hh" / TV Player). The Android launcher
is a native Kotlin UI; a WebView shell and a local HTTP server still ship as the
web/fallback layer.

## Layout

- `static/` — the web UI: `index.html`, `style.css`, `app.js`, embedded
  `channels-data.js` (`HH_CHANNELS`), `sw.js`, `icons/`, `vendor/hls.min.js`.
- `android/app/src/main/kotlin/` — the native UI: `ui/` screens, `player/`
  ExoPlayer + MediaSessionService, `data/` channel list + Room favourites,
  `model/` the `Channel` type.
- `android/` — Gradle project. `MainActivity.java` is the old WebView shell; it
  is no longer the launcher.
- `dist/` — release artifacts (`TV-Player.apk`).
- `server.py` — serves the app and the APK download endpoints.

## Build

```bash
cd android
export JAVA_HOME=/workspace/tools/jdk-17.0.20.1+1
export ANDROID_SDK_ROOT=/workspace/tools/android-sdk
/workspace/tools/gradle/gradle-8.7/bin/gradle :app:assembleRelease --no-daemon
cp app/build/outputs/apk/release/app-release.apk ../dist/TV-Player.apk
```

`app.js` is written in ES5 and must stay that way; validate with
`node --check static/app.js` and `npx acorn@8 --ecma5 static/app.js`.

## Player architecture

Two players share one UI, chosen at runtime:

- Browser: the `<video>` element plus `hls.js`.
- APK: the native Media3 ExoPlayer. `nativePlayer()` returns the
  `window.AndroidPlayer` bridge when present, and every control path checks it
  first. **Any new playback or widget code must go through this check** — the
  `<video>` element is inert in the APK.

`MainActivity` reports back with `window.tvNativeEvent(type, payload)`
(`state`, `retry`, `stopped`). There are no DOM events from the native player,
so anything that used to listen on `<video>` must also be driven from that
notification (this is how the radio widget is refreshed).

`stageBounds()` scales by `devicePixelRatio`: `getBoundingClientRect` is CSS
pixels while the native View is laid out in physical pixels. Without the scale
the native player opens as a small box.

## Permissions

Only `INTERNET` and `ACCESS_NETWORK_STATE`. No storage permission on any API
level — channel lists are embedded in the APK, not read from disk. Keep it that
way; do not add `READ_*`/`WRITE_*_STORAGE` or `MANAGE_EXTERNAL_STORAGE`.

## Radio widgets

`RadioWidgetBase` + Small/Medium/Large show the playing station with
prev/play/next. They are radio-only: a widget press while a TV channel is up
jumps to the last radio station. They read their state from the
`AndroidWidget` bridge, which the web UI feeds from the native player state.
A widget press cold-starts the activity, so `widgetCmd` queues the command in
`pendingCmd` until the page calls `ready()`.

## UI

- Bottom tab bar (phone): Canlı TV / Radyo / Favoriler, each with a distinct
  icon. Settings open from the gear button as a full pane.
- The channel browser is a tree (accordion): a group expands in place to list
  its channels, opening another group collapses the previous one
  (`state.openGroup`). The flat channel pane is only used for favourites/search
  (`.flat-list`).
- Selecting a channel opens the player full screen (`#app.playing`); the back
  button returns to the list.
- On the phone, show "TV Player" wherever the source says "hh".

### Native UI (Kotlin)

The launcher is `BottomNavActivity` (see `ui/`). Layouts are:

- `activity_bottom_nav.xml` — `fragmentHost` + `BottomNavigationView`. The nav
  bar uses `bg_nav_bar` (hairline on top), `nav_item_tint` and the
  `NavItemIndicator` pill for the checked item.
- `fragment_channel_list.xml` — fixed header (`bg_header`: brand mark
  `bg_brand_mark` + `ic_brand_tv`, active tab name, search card `bg_search`
  with `ic_search` and a `searchClear` button) over the `ExpandableListView`.
  `listCount` shows the filtered total; `emptyState` is contextual (search
  miss / no favourites / empty list). `ChannelListFragment` fills `headerTitle`
  per tab and toggles `searchClear` from the text watcher. The bottom bar
  (`bottom_nav_menu.xml`) has four tabs: Canlı TV, Radyo, Listeler (`MODE_ALL`,
  live + radio grouped) and Favoriler.
- `list_group_item.xml` / `list_child_item.xml` — rounded cards
  (`bg_group_card` / `bg_children_card`). The group row has an accent bar
  (`bg_group_accent`), a count pill (`bg_count_pill`) and a chevron rotated by
  `ExpandableChannelAdapter`. The child row has a logo tile (`bg_logo_tile`)
  with a letter fallback and a favourite star.
- `activity_player.xml` — `PlayerView` with `use_controller=false`, so the
  built-in controller never shows. A top scrim (`bg_player_top`) holds back,
  title, group, screen-mode and fullscreen; a bottom scrim
  (`bg_player_bottom`) holds prev / play-pause / next and the status line.

`PlayerActivity` reuses the single `PlaybackController` player, loads the whole
group as a playlist (so Next/Previous change channels) and cycles
FIT/FILL/ZOOM. It resolves that playlist through `UserChannelStore` — not
`ChannelRepository` — so a channel the user added or edited is the one that
plays, and it receives the tapped channel by URL (`EXTRA_URL`) rather than by
index. The activity opens straight into fullscreen and auto-hides the top and
bottom scrims after 4s; tapping the picture toggles them back. The fullscreen
button toggles the system bars via `WindowInsetsControllerCompat`.

Widgets work from a cold start: `PlayerService.ensureRadioLoaded()` loads the
radio list itself before handling PLAY/TOGGLE/NEXT/PREV, so a widget tap can
never start a TV stream.

TV boxes: the manifest declares touchscreen and leanback as optional and the
launcher activity carries `LEANBACK_LAUNCHER`, so the app installs and shows up
on a box/Android TV home screen. Remote control works through `dispatchKeyEvent`
in `PlayerActivity` (D-pad left/right and media keys change channel, centre and
play/pause toggle, back exits) and through focusable list rows: the channel
adapter needs `listView.setItemsCanFocus(true)` plus `focusable`/`clickable`
row cards, otherwise the D-pad stops on the list itself and never reaches a
row. The channel row's click listener lives on `rowCard`, not the outer row, so
touch selection keeps working.

Do not put `setArtworkUri` on `MediaItem` metadata. The legacy MediaSession stub
scales artwork bitmaps on the main thread while building `MediaMetadata`, which
blocks input long enough to trigger an ANR ("Input dispatching timed out") on
the first channel change. Titles and artists are enough for the notification;
logos are drawn by Glide in the UI.

Build: `cd android && ./gradlew :app:assembleRelease` (wrapper is checked in;
CI uses the same command). Do not run `build_apk.py` for the native app — it
only packages the WebView fallback.

Desktop build: `python build/make.py` produces `dist/hh` (Linux) or
`dist/hh.exe` (Windows) and `build_exe.bat` is the double-click Windows path;
`python build/package_source.py` refreshes `build/pkg/hh-Kaynak.zip`.

## Toolchain versions (do not downgrade)

The APK needs a newer AndroidX Media3 than the original 1.3.1. Media3 1.11.1
pulls `kotlin-stdlib:2.2.10`, so the Kotlin plugin and KSP had to move with it,
and Room with KSP. The versions are coupled:

- AGP 8.10.1, Gradle 8.11.1, `compileSdk 36` (platform + build-tools 36)
- Kotlin 2.2.10, KSP 2.2.10-2.0.2
- Media3 1.11.1, Room 2.7.1, `minSdk 28`, `targetSdk 34`

Dropping any one of these below its partner produces a build failure, not a
warning: Media3 1.11.1's stdlib metadata is 2.2.0, so Kotlin < 2.2.10 fails with
"Module was compiled with an incompatible version of Kotlin", and Room 2.6.1
under KSP 2.2.x fails with "unexpected jvm signature V". CI installs
`platforms;android-36` and `build-tools;36.0.0` for the same reason.

## Live channel startup

Live HLS used to take ~26s to first frame. Two things fixed it, and both live
in `PlaybackController.build()`:

- `DefaultMediaSourceFactory` live offsets: target 3s, min 1.5s, max 15s, with
  speed 0.97–1.08. Without an explicit target the player starts ~30s behind the
  live edge, which is what made a channel look hung.
- `DefaultLoadControl.setBufferDurationsMs(8_000, 60_000, 1_000, 2_000)`: the
  third value is how much buffer is required before the first frame, and the old
  15s minimum delayed playback by ~20s on 24-hour playlists.

Measured on the emulator: TRT1 26s → ~10s, Show TV 18.8s → ~10s, Star TV 16s →
~8s. TRT1 reports `liveOffset` as unset because its playlist carries an absolute
media timeline with no `#EXT-X-PROGRAM-DATE-TIME`, so the live-edge offset is
not computable there; it still plays. The remaining TRT1 delay is the ~5.8s it
waits to accumulate the minimum buffer before the first frame plus segment
download latency — deliberate, not a stall.

`TVPERF` logging (an OkHttp interceptor plus an `AnalyticsListener`) was used to
measure this and has been removed; re-add it temporarily if startup regresses.


## Session notes: list ordering, Turkish-only filter, stop/rotate (2026-10)

Channel ordering
- The bundled order in data/channels.json is the broadcaster importance
  ranking (TRT 1, Show TV, Star TV, Kanal 7, ATV ...). Do not sort channels
  alphabetically in the app: ChannelRepository.grouped() deliberately keeps
  first-seen order for both groups and channels. An earlier Collator sort is
  what made the user report sorting was completely lost. An Hepsi (All)
  group is pinned first.

Turkish-only list
- /tmp/tvlists/build_list.py drops non-Turkish broadcasters. The regex must
  run on both the raw and the clean_name() value, because sources list them
  as TRT Arabi HD and only the cleaned name matches. Removed: TRT Arabi,
  Avaz, Kurdi, World, and the Arabic .Al quran radio. Placeholder hosts
  (http://missing) and .php web pages are also filtered.
- Rebuild by restoring /tmp/tvlists/channels.json.bak over
  /workspace/hh/data/channels.json first - running the script on its own
  merged output makes (2)/(3) mirror rows look like separate channels.
  Result: 666 unique channels / 872 address rows / 247 radio.

Stop button
- player.stop() alone was not enough: REPEAT_MODE_ALL plus the
  MediaSessionService could re-arm playback. PlaybackController.stop() now
  sets playWhenReady=false, then stop(), then clearMediaItems(), and
  remembers lastChannel so Play resumes it. notifyState() reports
  STATE_IDLE as stopped (previously mislabelled paused) and the activity
  handles that state by clearing the transport.

Build / release
- JAVA_HOME=/workspace/tools/jdk-17.0.20.1+1 ./gradlew assembleRelease.
- Publish with cp app/build/outputs/apk/release/app-release.apk ../dist/TV-Player.apk;
  the static server serves /workspace/hh/dist.

Playback engine: LibVLC (was Media3/ExoPlayer)
- deps: org.videolan.android:libvlc-all:3.7.7 (no ExoPlayer). The AAR ships
  libvlc/libvlcjni/libc++_shared for 4 ABIs, so the release APK is ~200 MB.
- LibVLC's Context+List constructor appends --aout/--android-display-chroma
  to the options list it is given. Pass a MUTABLE list (mutableListOf); a
  Kotlin listOf() makes it throw UnsupportedOperationException at runtime.
- The video surface is a org.videolan.libvlc.util.VLCVideoLayout; attach in
  PlayerActivity.onResume and detach in onPause so audio keeps playing while
  the screen is off. PlaybackController owns one shared MediaPlayer created
  with a detached SurfaceView (no VLCVideoLayout) so radio works with no UI.
- keep rules for org.videolan.libvlc.** are required (JNI/modules load by name).
- Runtime testing needs a working emulator; the container has no /dev/kvm, so
  x86_64 AVDs refuse to start. A previously running emulator worked before a
  host restart - use one if the environment provides it, otherwise the build
  is validated by compile + apksigner verify + aapt2 badging only.

Integrity, version stamp and CI gate (BOLUM 16)
- One source of truth: the root VERSION file. static/index.html and
  static/sw.js carry ?v=<stamp>; the service-worker shell name is
  tv-shell-<stamp>. build/verify_integrity.py --fix rewrites them and checks
  the chain (channels.json -> channels-data.js -> android assets). server.py
  exposes the stamp at /api/version and app.js compares it with the stamp
  embedded in channels-data.js (window.HH_VERSION): a mismatch clears every
  cache, unregisters the worker and reloads once.
- CI runs a `guard` job before build/apk (needs: guard): node --check,
  `npx acorn@8 --ecma5 static/app.js`, an ast.parse + stdlib-only check on
  server.py, verify_integrity.py and check_vectors.py. Red guard = no packages.
- Channel-list fallback: embedded list first, then /api/channels, then the last
  good list cached in localStorage under tv.channels.cache, labelled
  "Son liste: HH:MM" (#listStamp).
- The probe cache lives in data/probe-cache.json ({at, ...} entries). Do NOT
  point it at data/urlcheck.json: apply_health.py reads that file as a list of
  health rows.

Android TV remote (box) behaviour
- Web layer: .ch/.tree-row/.gchip/.tabbtn/.more-toggle get a fixed amber
  :focus ring because a D-pad focuses programmatically and :focus-visible is
  not triggered on many WebViews. keydown handles raw codes 13 (OK -> click
  the focused .ch), 427/428 (CH+/CH- -> zap) and 8/461 (BACK). The list render
  restores focus to the same channel url (or the first row). The
  "+N daha göster" button has tabindex=0 and loads the next page on focus.
- Native: PlayerActivity.dispatchKeyEvent maps DPAD_UP/CHANNEL_UP to previous
  and DPAD_DOWN/CHANNEL_DOWN to next; MENU shows the controls; BACK calls
  stopLiveOnExit(). VLCVideoLayout is focusable=false so it never steals focus.

Packaging
- APK: cd android && JAVA_HOME=/workspace/tools/jdk-17.0.20.1+1 \
  ANDROID_SDK_ROOT=/workspace/tools/android-sdk ./gradlew :app:assembleRelease.
  Publish app-{arm64-v8a,armeabi-v7a,universal}-release.apk to dist/TV-Player*.apk
  and build/pkg/. The first run needs network for AGP/aapt2; --offline fails
  because aapt2 8.10.1 is not cached.
- Sources: python3 build/package_source.py writes hh-Kaynak.zip and, when
  7z / py7zr / /workspace/tools/rar/rar are present, .7z and .rar too. The
  archives never include data/store.json (playlist credentials).

Signing and secrets (BOLUM 17)
- The release keystore is fixed: android/app/hh-release.jks, alias hhkey. It is
  tracked in git on purpose so an update keeps the same signature; do NOT add
  *.jks to .gitignore (only *.keystore / .keystore-pass / *-pass.txt are
  ignored). Changing the keystore or alias breaks in-place updates on a box.
- The passwords are no longer hard-coded in build.gradle: read them from
  -PTV_STORE_PASS / -PTV_KEY_PASS or the TV_STORE_PASS / TV_KEY_PASS env vars,
  falling back to the historical value. sign_apk.bat re-signs a raw APK and
  uses the correct apksigner syntax `--ks-pass env:TV_STORE_PASS` (note the
  colon; `--ks-pass:env NAME` is invalid and silently fails).

User data persistence and playback (BOLUM 17)
- Added channels ("+ Kanal") are stored in state.added, persisted to the server
  store key `added` and to localStorage, and re-applied on every load by
  applyAdded() (which skips duplicates). deleteChannel() removes them from
  `added` too, so a deleted channel does not come back.
- Web last-working mirror: localStorage tv.mirror.v1 maps a channel key to the
  URL that last played; play() calls preferredChannel() to open straight on it.
  The native player keeps the same idea in SharedPreferences.
- Web black-frame watchdog: after 3 s of "playing" with videoWidth === 0 it
  tries the next mirror and shows "Ayna N deneniyor". Skipped for radio and in
  the APK (the native player has its own).
- Backup: Ayarlar -> Yedek exports tv-yedek.json (snapshot()) and restores it
  via applySnapshot + applyAdded/applyDeleted. It carries favourites, added
  channels, overrides and deletions, but never the playlist credentials.
- server.py POST /api/store now merges the keys "deleted" and "added" too;
  _default_store() seeds them so an older store.json does not drop them.
- PROBE_TTL is 86400 (one sweep a day). The 7-day dead-URL drop lives in
  build/refresh_health.py; do not confuse the probe cache with urlcheck.json.
